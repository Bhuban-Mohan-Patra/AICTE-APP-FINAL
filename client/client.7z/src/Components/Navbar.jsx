import React from 'react'

export const Navbar = () => {
  return (
    <div style={{'height':'10vh','backgroundColor':'gray' }} >Navbar</div>
  )
}
