import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap";
import { Routes, Route } from "react-router-dom";
import {EduProfile} from './Components/EduProfile';
import {DesProfile} from './Components/DesProfile';
import { Navbar } from "./Components/Navbar";
import {CreateCurr} from './Components/CreateCurr';

import {Home} from './Components/Home';
function App() {
  return (
    <>
    <Navbar/>
    <Routes>
        <Route exact path='/' element={<Home/>}  />
        {
          localStorage.getItem('type')==='educator'?  <Route exact path='/profile' element={<EduProfile/>} ></Route> :  <Route exact path='/profile' element={<DesProfile/>} ></Route>
        }

       <Route exact path='/create' element={<CreateCurr/>} />
    </Routes>
    </>
  );
}

export default App;
